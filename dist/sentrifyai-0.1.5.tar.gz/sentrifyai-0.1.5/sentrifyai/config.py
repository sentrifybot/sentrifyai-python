BASE_URL = 'http://api.sentrifyai.org/v1/'
